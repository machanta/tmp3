package com.co.pdi.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

public class TestTokens {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         TestTokens t = new TestTokens();
      //   t.parse("init@p1=0 15 10 ? * MON-FRI;p2=0 15 10 ? * 6L 2002-2005;p3=0 15 10 ? * 6L:sched@p1=v1;p2=0 10,44 14 ? 3 WED");
         
         HashMap<String, HashMap<String, String>> retMap = t.parseX("init@p1=0 15 10 ? * MON-FRI;p2=0 15 10 ? * 6L 2002-2005;p3=0 15 10 ? * 6L:sched@p1=v1;p2=0 10,44 14 ? 3 WED");
         for (Iterator<String> it = retMap.keySet().iterator(); it.hasNext();) {
        	   String serviceName = it.next();
        	   HashMap<String,String> pMap = retMap.get(serviceName);
        	   if (serviceName != null  ) {
    			   
     			  
			        System.out.println("\n\n****\n\nService Name = " + serviceName );
					 if (pMap != null) {
						 
						 for (Iterator<String> itx = pMap.keySet().iterator(); itx.hasNext();) {
							        String key = itx.next();
							        String value = pMap.get(key);
							        System.out.println("       " + key + "   =   "  + value);

						 }
					 } 
	 
		   }
         }
	}

	
	public TestTokens() {
		
	}
	
	
private HashMap<String, HashMap<String, String>> parseX( String initServices) {
		
		HashMap<String, HashMap<String, String>> retMap = new HashMap<String, HashMap<String, String>>();
	      if (initServices != null) {
	       	   StringTokenizer token1 = new StringTokenizer(initServices, ":");
	       	   while(token1.hasMoreTokens()) {
	       		   String service = token1.nextToken();
	       		   StringTokenizer token2 = new StringTokenizer(service, "@");
	       		   int i=0;
	       		   String serviceName = null; 
	       		   HashMap<String, String> pMap = new HashMap<String, String>();
	       		   while(token2.hasMoreElements()) {
	       			   String str = token2.nextToken();
	       			   if (i==0) {
	       				   serviceName = str;
	       				}
	       			   else { 
	       				  StringTokenizer token3 = new StringTokenizer(str, ";");
	       				  while(token3.hasMoreTokens()) {
	       					  StringTokenizer token4 = new StringTokenizer(token3.nextToken(), "=");
	       					  String key=null, value=null; int j=0;
	       					  
	       					  while (token4.hasMoreTokens()) {
	       						  if ( j==0)  key = token4.nextToken();
	       						  else 
	       							value = token4.nextToken();
	       						  
	       						  j++;
	       					  }
	       					  if (key !=null & value != null ) pMap.put(key, value);
	       					  
	       				  }
	       			   }
	       			   i++;
	       		   }
	       		   
	       		   if (serviceName != null  ) {
	       			   
	       			   retMap.put(serviceName,pMap);
							//runService(dir, serviceName, pMap, null,null);
						  
	       		   }
	       		   
	       	   }
	       	   
	         }	
		
	      return retMap;
	}
	
	private void parse(String initServices) {
		   if (initServices != null) {
	        	   StringTokenizer token1 = new StringTokenizer(initServices, ":");
	        	   while(token1.hasMoreTokens()) { 
	        		   String service = token1.nextToken();
	        		   StringTokenizer token2 = new StringTokenizer(service, "@");
	        		   int i=0;
	        		   String serviceName = null; 
	        		   HashMap<String, String> pMap = new HashMap<String, String>();
	        		   while(token2.hasMoreElements()) {
	        			   String str = token2.nextToken();
	        			   if (i==0) {
	        				   serviceName = str;
	        				}
	        			   else { 
	        				  StringTokenizer token3 = new StringTokenizer(str, ";");
	        				  while(token3.hasMoreTokens()) {
	        					  StringTokenizer token4 = new StringTokenizer(token3.nextToken(), "=");
	        					  String key=null, value=null; int j=0;
	        					  
	        					  while (token4.hasMoreTokens()) {
	        						  if ( j==0)  key = token4.nextToken();
	        						  else 
	        							value = token4.nextToken();
	        						  
	        						  j++;
	        					  }
	        					  if (key !=null & value != null ) pMap.put(key, value);
	        					  
	        				  }
	        			   }
	        			   i++;
	        		   }
	        		   
	        		   if (serviceName != null  ) {
	        			   
	        			  
						        System.out.println("\n\n****\n\nService Name = " + serviceName );
								 if (pMap != null) {
									 
									 for (Iterator<String> it = pMap.keySet().iterator(); it.hasNext();) {
										        String key = it.next();
										        String value = pMap.get(key);
										        System.out.println("       " + key + "   =   "  + value);
           
									 }
								 } 
				 
	        		   }
	}
 }
		   
		   
	}

}
package com.co.pdi.web;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.pentaho.di.core.KettleEnvironment;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.core.util.EnvUtil;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.quartz.CronTrigger;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;

import org.quartz.impl.StdSchedulerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Servlet implementation class getKettle
 */
//@WebServlet("/service")
public class getKettle extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
	public static Scheduler sched;
	 Logger log = LoggerFactory.getLogger(getKettle.class);
	 
    public getKettle() {
        super();
     
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
    @Override
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init(config);
		   try {
			 //  -DKETTLE_PLUGIN_BASE_FOLDERS=path_to_your_data-integration/plugin
			   String pluginDir =   config.getServletContext().getInitParameter("pluginDir");
			   if (pluginDir != null) {
				   System.setProperty("KETTLE_PLUGIN_BASE_FOLDERS", pluginDir);
			   }
			   log.info("Servlet Service(getKettle) Init started");
			   System.out.println("Servlet Service(getKettle) Init started");
			   
			   System.out.println("Plugin Directory value  is " + System.getProperty("KETTLE_PLUGIN_BASE_FOLDERS"));
			   
				KettleEnvironment.init(false);
				 
				String dir =   config.getServletContext().getInitParameter("ktrDir");
				if (dir!= null && !(dir.startsWith("/") || dir.indexOf(":") > 0)) {
					
					String userDir = System.getProperty("user.dir");
					dir = userDir + File.separator + dir;
				}
				System.out.println("Init Directory value  is " + dir);
				log.info("Init Directory value is " + dir);
				
	 	            if (dir == null ) {
		            	
		            	System.out.println("Init Directory is null (Sout)");
		            	log.error("Init Directory is null (log)");
		            }
	 	            else {
	 	              String initServices =   config.getServletContext().getInitParameter("initServices");
	 	              if (initServices != null)
	 	                  runInitServices(dir, initServices);
	 	              runSchedulder(dir);
	 	              
	 	             Runtime.getRuntime().addShutdownHook(new Thread() {
	 	                public void run() {
	 	                   try {
							getKettle.getSched().shutdown(true);
						} catch (SchedulerException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}      
	 	                }
	 	            });
	 	            }

	 	            
			} catch (KettleException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	 

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
       
			String dir = request.getSession().getServletContext().getInitParameter("ktrDir");
			if (dir!= null && !(dir.startsWith("/") || dir.indexOf(":") > 0)) {
				
				String userDir = System.getProperty("user.dir");
				dir = userDir + File.separator + dir;
				
			}
			System.out.println("doGet Directory value  is " + dir);
          //  String dir = request.getServletContext().getInitParameter("ktrDir");
            if (dir == null ) {
            	
            	System.out.println("doGet Directory is null");
            	log.error("doGet Directory is null");
            }
            String sName = request.getParameter("sName");
            runService(dir,sName, null, request, response);
            
            
		 
       
        
   	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	private void   runSchedulder(String dir) {
		
		log.info("initializing  Scheduler");
     SchedulerFactory sf = new StdSchedulerFactory();
     try {
		 getKettle.setSched(sf.getScheduler());
		Properties prop = new Properties();
		prop.load(new FileInputStream(dir + "scheduler.prop"));
       String schedule =  prop.getProperty("schedule");
       if (schedule != null) {
    	   HashMap <String,HashMap<String, String>> retMap = parse(schedule);
    	   int i=0;
    	      for (Iterator<String> it = retMap.keySet().iterator(); it.hasNext();) {
    	       	   String serviceName = it.next();
    	       	   HashMap<String,String> pMap = retMap.get(serviceName);

    	       		   
    	       		   if (serviceName != null && pMap.containsKey("cron") ) {
    	       			   
    	       			  String cron = pMap.get("cron");
    	       		      JobDetail job = newJob(ServiceJob.class)
    	       		            .withIdentity(pMap.containsKey("job")? (String)pMap.get("job") : "scheduleJob"+i, pMap.containsKey("group")? (String)pMap.get("group") : "group" +i)
    	       		            .build();
    	       		        
    	       		        CronTrigger trigger = newTrigger()
    	       		            .withIdentity(pMap.containsKey("trigger")? (String)pMap.get("trigger") : "trigger" +i, pMap.containsKey("group")? (String)pMap.get("group") : "group" +i)
    	       		            .withSchedule(cronSchedule(cron))
    	       		            .build();
    	       		        job.getJobDataMap().put("sName", serviceName);
    	       		        job.getJobDataMap().put("ktrDir", dir);
    	       		        job.getJobDataMap().putAll(pMap);
    	       		     
    	       		        Date ft = sched.scheduleJob(job, trigger);
    	       		        System.out.println(job.getKey() + " has been scheduled to run at: " + ft
    	       		                + " and repeat based on expression: "
    	       		                + trigger.getCronExpression());
    	       		     log.info(job.getKey() + " has been scheduled to run at: " + ft
 	       		                + " and repeat based on expression: "
 	       		                + trigger.getCronExpression());
    	       		     getSched().start();
    	       		   }
    	       		   i++;
    	      }
       }
		 
	 
		
	} catch (SchedulerException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
		System.out.println("Scheduler Service Failed");
		log.error("Scheduler Service Failed");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Scheduler Service Failed");
		log.error("Scheduler Service Failed");
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Scheduler Service Failed");
		log.error("Scheduler Service Failed");
	}
    
    
	}
	
	
	private HashMap<String, HashMap<String, String>> parse( String initServices) {
		
		HashMap<String, HashMap<String, String>> retMap = new HashMap<String, HashMap<String, String>>();
	      if (initServices != null) {
	       	   StringTokenizer token1 = new StringTokenizer(initServices, ":");
	       	   while(token1.hasMoreTokens()) {
	       		   String service = token1.nextToken();
	       		   StringTokenizer token2 = new StringTokenizer(service, "@");
	       		   int i=0;
	       		   String serviceName = null; 
	       		   HashMap<String, String> pMap = new HashMap<String, String>();
	       		   while(token2.hasMoreElements()) {
	       			   String str = token2.nextToken();
	       			   if (i==0) {
	       				   serviceName = str;
	       				}
	       			   else { 
	       				  StringTokenizer token3 = new StringTokenizer(str, ";");
	       				  while(token3.hasMoreTokens()) {
	       					  StringTokenizer token4 = new StringTokenizer(token3.nextToken(), "=");
	       					  String key=null, value=null; int j=0;
	       					  
	       					  while (token4.hasMoreTokens()) {
	       						  if ( j==0)  key = token4.nextToken();
	       						  else 
	       							value = token4.nextToken();
	       						  
	       						  j++;
	       					  }
	       					  if (key !=null & value != null ) pMap.put(key, value);
	       					  
	       				  }
	       			   }
	       			   i++;
	       		   }
	       		   
	       		   if (serviceName != null ) {
	       			   
	       			   retMap.put(serviceName,pMap);
						
						  
	       		   }
	       		   
	       	   }
	       	   
	         }	
		
	      return retMap;
	}
	private void runInitServices(String dir, String initServices) {
		
        HashMap<String, HashMap<String, String>> retMap = parse(initServices);
        for (Iterator<String> it = retMap.keySet().iterator(); it.hasNext();) {
       	   String serviceName = it.next();
       	   HashMap<String,String> pMap = retMap.get(serviceName);

       		   
       		   if (serviceName != null && dir != null ) {
       			   
       			   try {
						runService(dir, serviceName, pMap, null,null);
						System.out.println("\n\n*****Running Init Service *****\n" + serviceName + "\n************\n");	
						log.error("\n\n*****Running Init Service *****\n" + serviceName + "\n************\n");	

					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						log.error(e.toString());
					}
       		   }
        }   
      
	}
	private void runService(String serviceDir, String serviceName, HashMap<String, String> pMap, HttpServletRequest request, HttpServletResponse response) throws IOException{
		
	       TransMeta metaData;
	 /*      try {
			KettleEnvironment.init(false);
		} catch (KettleException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} */
			try {
				
				//EnvUtil.environmentInit();
				
				    if (serviceDir == null || serviceName == null ) {
	            	
	            	   System.out.println("Directory or Service Nme is null");
	            	   log.error("Directory or Service Nme is null");
	              }
	             
				metaData = new TransMeta(serviceDir +serviceName + ".ktr");
				 Trans trans = new Trans( metaData );
				 if (response != null) 
				 trans.setServletPrintWriter(response.getWriter());
				 
				 if (pMap != null) {
					 
					 for (Iterator<String> it = pMap.keySet().iterator(); it.hasNext();) {
						        String key = it.next();
						        String value = pMap.get(key);
						        trans.setParameterValue(key, value);
					 }
				 }
				 
				 if (request != null) {
					Enumeration  <String> pNames = request.getParameterNames();
					for (;pNames.hasMoreElements(); ) {
						String str = pNames.nextElement();
						if (str != null) {
						 String [] values =	request.getParameterValues(str);
						 for (int i=0; i<values.length; i++) {
						     System.out.println("parameter: " + str + " value[" +i +"] = " + values[i] );
						     
						   }
						 
						 trans.setParameterValue(str, values[0]);
						}
						
					}
				 }
				 
			     trans.execute( null );
			        trans.waitUntilFinished();
			        if ( trans.getErrors() > 0 ) {
			            System.out.print( "Error Executing transformation" );
			            log.error( "Error Executing transformation" );
			        }


			} catch (KettleXMLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.error(e.toString());
			} catch (KettleException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.error(e.toString());
			}
	       
		
		
	}

	public static Scheduler getSched() {
		return sched;
	}

	public static void setSched(Scheduler sched) {
		getKettle.sched = sched;
	}
}

package com.co.pdi.web;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServiceJob implements Job {

	
	Logger log = LoggerFactory.getLogger(ServiceJob.class);
	
	  public ServiceJob() {
		  
	    }
	@Override
	public void execute(JobExecutionContext jec) throws JobExecutionException {
		
	    TransMeta metaData;
	    JobDataMap jMap =  jec.getJobDetail().getJobDataMap();
        String jobName = jec.getJobDetail().getKey().getName();
        String triggerName = jec.getTrigger().getKey().getName();
        String group = jec.getJobDetail().getKey().getGroup();
        
	    String serviceDir = jec.getJobDetail().getJobDataMap().getString("ktrDir");
	    String serviceName = jec.getJobDetail().getJobDataMap().getString("sName");
		System.out.println("\n\n*****Running Scheduled Service *****\n" + "jobname = " + jobName + "   Trigger Name=" + triggerName +  "   Group Name = " + group + "\n Service Name = " + serviceName +  "\n************\n");	 
		log.error("\n\n*****Running Scheduled Service *****\n" + "jobname = " + jobName + "   Trigger Name=" + triggerName +  "   Group Name = " + group + "\n Service Name = " + serviceName +  "\n************\n");	 

				try {
					
					    if (serviceDir == null || serviceName == null ) {
		            	
		            	   System.out.println("Directory or Service Nme is null");
		            	   log.error("Directory or Service Nme is null");
		              }
		             
					metaData = new TransMeta(serviceDir +serviceName + ".ktr");
					 Trans trans = new Trans( metaData );
 					 
					 if (jMap != null) {
						 
						 for (Iterator<String> it = jMap.keySet().iterator(); it.hasNext();) {
							        String key = it.next();
							        String value = (String) jMap.get(key);
							        trans.setParameterValue(key, value);
						 }
					 }
					 
		 
					 
				     trans.execute( null );
				        trans.waitUntilFinished();
				        if ( trans.getErrors() > 0 ) {
				            System.out.print( "Error Executing transformation" );
				            log.error( "Error Executing transformation" );
				            
				        }


				} catch (KettleXMLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					log.error(e.fillInStackTrace().toString());
				} catch (KettleException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					log.error(e.fillInStackTrace().toString());
				}

	}

}

package com.co.pdi.test;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.pentaho.di.core.KettleEnvironment;
import org.pentaho.di.core.exception.KettleException;
import org.pentaho.di.core.exception.KettleXMLException;
import org.pentaho.di.trans.Trans;
import org.pentaho.di.trans.TransMeta;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

 

public class TestKettle {
	Logger log = LoggerFactory.getLogger(TestKettle.class);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TestKettle k = new TestKettle();
		try {
			k.runService("/Users/machanta/java/ktr/", "testJSON1", new HashMap<String,String>(), null,null);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private void runService(String serviceDir, String serviceName, HashMap<String, String> pMap, HttpServletRequest request, HttpServletResponse response) throws IOException{
		
	       TransMeta metaData;
			try {
				KettleEnvironment.init(false);
				//EnvUtil.environmentInit();
				
				    if (serviceDir == null || serviceName == null ) {
	            	
	            	   System.out.println("Directory or Service Nme is null");
	            	   log.error("Directory or Service Nme is null");
	              }
	             
				metaData = new TransMeta(serviceDir +serviceName + ".ktr");
				 Trans trans = new Trans( metaData );
				 if (response != null) 
				 trans.setServletPrintWriter(response.getWriter());
				 
				 if (pMap != null) {
					 
					 for (Iterator<String> it = pMap.keySet().iterator(); it.hasNext();) {
						        String key = it.next();
						        String value = pMap.get(key);
						        trans.setParameterValue(key, value);
					 }
				 }
				 
				 if (request != null) {
					Enumeration  <String> pNames = request.getParameterNames();
					for (;pNames.hasMoreElements(); ) {
						String str = pNames.nextElement();
						if (str != null) {
						 String [] values =	request.getParameterValues(str);
						 for (int i=0; i<values.length; i++) {
						     System.out.println("parameter: " + str + " value[" +i +"] = " + values[i] );
						     
						   }
						 
						 trans.setParameterValue(str, values[0]);
						}
						
					}
				 }
				 
			     trans.execute( null );
			        trans.waitUntilFinished();
			        if ( trans.getErrors() > 0 ) {
			            System.out.print( "Error Executing transformation" );
			            log.error( "Error Executing transformation" );
			        }


			} catch (KettleXMLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.error(e.toString());
			} catch (KettleException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				log.error(e.toString());
			}
	       
		
		
	}

}

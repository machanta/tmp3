/**
 * Copyright Camunda Services GmbH and/or licensed to Camunda Services GmbH
 * under one or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information regarding copyright
 * ownership.
 *
 * Camunda licenses this file to you under the MIT; you may not use this file
 * except in compliance with the MIT License.
 */

window.backend =
 {
   send,
   on,
   once,
   sendQuitAllowed,
   sendQuitAborted,
   sendReady,
   showContextMenu,
   sendTogglePlugins,
   sendMenuUpdate,
   registerMenu,
   getPlatform
 };

function send(event, ...args) {
  console.log('Send...' + event + args);

  const id = uuidv4();

  return new Promise((resolve, reject) => {

    once(event + ':response:' + id, function(evt, args) {
      if (args[0] !== null) {
        reject(args[0]);
      }

      // promises can only resolve with one argument
      return resolve(args[1]);
    });

    PubSubManager.sendToBackEnd(event, id, args);
  });
}


function on(event, callback) {
  console.log('On...' + event);
  PubSubManager.subscribe(event,callback);
  return {
    cancel() {
      console.log('cancel');
      PubSubManager.off(event,callback);
    }
  };

}

function once(event, callback) {
  console.log('Once Event ' +event);
  PubSubManager.subscribeOnce(event,callback);
  return {
    cancel() {
      console.log('cancel');
      PubSubManager.off(event,callback);
    }
  };
}

function sendQuitAllowed() {
  send('app:quit-allowed');
}

function sendQuitAborted() {
  send('app:quit-aborted');
}

function sendReady() {
  send('client:ready');
}

function showContextMenu(type, options) {
  send('context-menu:open', type, options);
}

function sendTogglePlugins() {
  send('toggle-plugins');
}

function sendMenuUpdate(state = {}) {
  send('menu:update', state);
}

function registerMenu(name, options) {
  return send('menu:register', name, options);
}

function getPlatform() {
  return 'Web';
}

function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
    return v.toString(16);
  });
}
var PubSubManager = {
  subscribers: [],
  subscribersOnce: [],
  backendSubscribers: [],
  subscribe: function(event, callback) {
    this.subscribers.push({ event: event, callback: callback });
    console.log('Subscribe ' + event);
  },
  subscribeOnce: function(event, callback) {
    this.subscribersOnce.push({ event: event, callback: callback });
    console.log('SubscribeOnce ' + event);
  },
  subscribeBackEnd: function(event, callback) {
    this.backendSubscribers.push({ event: event, callback: callback });
    console.log('SubscribeBackEnd ' + event);
  },
  sendToBackEnd: function(name, id,args) {

    // Notify subscribers of event.
    this.backendSubscribers.forEach(function(subscriber) {
      if (subscriber.event === name) {
        subscriber.callback(name, id,args);
        console.log('callback Backend' + name);
      }
    });


  },
  sendFromBackend: function(name, args) {

    // Notify subscribers of event.
    this.subscribers.forEach(function(subscriber) {
      if (subscriber.event === name) {
        subscriber.callback(name, args);
      }
    });
    this.subscribersOnce.forEach(function(subscriber) {
      if (subscriber.event === name) {
        subscriber.callback(name, args);
        console.log('Reply from backend ' + name);

        // this.removeOnceSubcscriber(name);
      }
    });

  },
  off: function(event, callback) {
    this.subscribers = this.subscribers.filter(function(subscriber) {
      if (!(subscriber.event == event && subscriber.callback === callback)) {
        return subscriber;
      }
    });
    this.removeOnceSubcscriber(event);
  },
  removeOnceSubcscriber : function(event) {
    this.subscribersOnce = this.subscribersOnce.filter(function(subscriber) {
      if (!(subscriber.event == event)) {
        return subscriber;
      }
    });
  }


};

// $(document).ready(function() {
console.log('ready!');
PubSubManager.subscribeBackEnd('config:get', function(event,id, args) {

  if (args && args[0] == 'editor.privacyPreferences') {
    console.log('editor.privacyPreferences received');
    PubSubManager.sendFromBackend(event+':response:'+id, [null,{}]);
  }
  if (args && args[0] == 'editor.id') {
    PubSubManager.sendFromBackend(event+':response:'+id, [null,uuidv4()]);
  }
  if (args && args[0] == 'versionInfo') {
    PubSubManager.sendFromBackend(event+':response:'+id, [null,{
      'lastOpenedVersion': '4.11.1'
    }]);
  }

  if (args && args[0] == 'bpmn.elementTemplates') {
    PubSubManager.sendFromBackend(event+':response:'+id, [null,[]]);
  }
});

PubSubManager.subscribeBackEnd('workspace:restore', function(event,id, args) {

  console.log(config.workspace.files.length);
  PubSubManager.sendFromBackend(event+':response:'+id, [null,config.workspace]);


});

PubSubManager.subscribeBackEnd('menu:register', function(event,id, args) {

  console.log('Menu Register' + args);
  PubSubManager.sendFromBackend(event+':response:'+id, [null,'registered']);


});

PubSubManager.subscribeBackEnd('client:ready', function(event,id, args) {


  PubSubManager.sendFromBackend('client:started', 'client:started');
  PubSubManager.sendFromBackend(event+':response:'+id, [null,'client:ready']);

});

PubSubManager.subscribeBackEnd('workspace:save', function(event,id, args) {

  // console.log('Menu Register' + args);
  PubSubManager.sendFromBackend(event+':response:'+id, [null,'Workspace Saved']);


});

PubSubManager.subscribeBackEnd('file:read-stats', function(event,id, args) {

  console.log('Read File Stats ' + args);
  PubSubManager.sendFromBackend(event+':response:'+id, [null,args]);


});

var config = {
  'workspace': {
    'files': [
      {
        'contents': '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="SendSignals_0" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="4.1.1">\n  <bpmn:process id="government" name="Spot price guvernor" isExecutable="false">\n    <bpmn:startEvent id="start">\n      <bpmn:outgoing>to-set-spot-price</bpmn:outgoing>\n    </bpmn:startEvent>\n    <bpmn:sequenceFlow id="to-set-spot-price" sourceRef="start" targetRef="set-spot-price" />\n    <bpmn:userTask id="set-spot-price" name="New spot price">\n      <bpmn:extensionElements>\n        <camunda:formData>\n          <camunda:formField id="newPrice" type="long" />\n        </camunda:formData>\n        <camunda:inputOutput>\n          <camunda:outputParameter name="spotPrice">${content.output.form.newPrice}</camunda:outputParameter>\n        </camunda:inputOutput>\n      </bpmn:extensionElements>\n      <bpmn:incoming>to-set-spot-price</bpmn:incoming>\n      <bpmn:outgoing>to-signal-new-price</bpmn:outgoing>\n    </bpmn:userTask>\n    <bpmn:endEvent id="end">\n      <bpmn:incoming>to-end</bpmn:incoming>\n    </bpmn:endEvent>\n    <bpmn:intermediateThrowEvent id="signal-new-price" name="Signal new spot price">\n      <bpmn:extensionElements>\n        <camunda:inputOutput>\n          <camunda:inputParameter name="price">${environment.output.spotPrice}</camunda:inputParameter>\n          <camunda:outputParameter name="price">${environment.output.spotPrice}</camunda:outputParameter>\n        </camunda:inputOutput>\n      </bpmn:extensionElements>\n      <bpmn:incoming>to-signal-new-price</bpmn:incoming>\n      <bpmn:outgoing>to-end</bpmn:outgoing>\n      <bpmn:signalEventDefinition id="SignalEventDefinition_16cusnm" signalRef="spotPriceUpdate" />\n    </bpmn:intermediateThrowEvent>\n    <bpmn:sequenceFlow id="to-signal-new-price" sourceRef="set-spot-price" targetRef="signal-new-price" />\n    <bpmn:sequenceFlow id="to-end" sourceRef="signal-new-price" targetRef="end" />\n  </bpmn:process>\n  <bpmn:signal id="spotPriceUpdate" name="newSpotPrice" />\n  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="government">\n      <bpmndi:BPMNEdge id="Flow_0v50c7i_di" bpmnElement="to-end">\n        <di:waypoint x="468" y="117" />\n        <di:waypoint x="532" y="117" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="Flow_195mvbw_di" bpmnElement="to-signal-new-price">\n        <di:waypoint x="370" y="117" />\n        <di:waypoint x="432" y="117" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="Flow_0or6sys_di" bpmnElement="to-set-spot-price">\n        <di:waypoint x="215" y="117" />\n        <di:waypoint x="270" y="117" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="start">\n        <dc:Bounds x="179" y="99" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="Activity_1n770rv_di" bpmnElement="set-spot-price">\n        <dc:Bounds x="270" y="77" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="Event_14d3dq8_di" bpmnElement="end">\n        <dc:Bounds x="532" y="99" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="Event_1ffls01_di" bpmnElement="signal-new-price">\n        <dc:Bounds x="432" y="99" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="411" y="142" width="78" height="27" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>',
        'lastModified': 1636152788684,
        'path': '/home/murali/development/javascript/bpmn-engine/test/resources/send-signal.bpmn',
        'name': 'send-signal.bpmn'
      },
      {
        'contents': '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.6.0">\n  <bpmn:process id="formProcess" isExecutable="true">\n    <bpmn:startEvent id="start">\n      <bpmn:extensionElements>\n        <camunda:formData>\n          <camunda:formField id="suggestedStartDate" label="Input date" type="date" defaultValue="${variables.now}">\n            <camunda:properties>\n              <camunda:property id="prop1" value="kl" />\n            </camunda:properties>\n            <camunda:validation>\n              <camunda:constraint name="mandatory" config="${true}" />\n            </camunda:validation>\n          </camunda:formField>\n        </camunda:formData>\n      </bpmn:extensionElements>\n      <bpmn:outgoing>SequenceFlow_0lj5hpw</bpmn:outgoing>\n    </bpmn:startEvent>\n    <bpmn:sequenceFlow id="SequenceFlow_0lj5hpw" sourceRef="start" targetRef="userTask" />\n    <bpmn:userTask id="userTask" name="With form">\n      <bpmn:extensionElements>\n        <camunda:formData>\n          <camunda:formField id="startDate" label="When to start" type="date" defaultValue="${defaultStartDate}" />\n        </camunda:formData>\n        <camunda:inputOutput>\n          <camunda:inputParameter name="defaultStartDate">${variables.suggestedStartDate}</camunda:inputParameter>\n          <camunda:outputParameter name="startDate" />\n        </camunda:inputOutput>\n      </bpmn:extensionElements>\n      <bpmn:incoming>SequenceFlow_0lj5hpw</bpmn:incoming>\n      <bpmn:outgoing>SequenceFlow_0apdac1</bpmn:outgoing>\n    </bpmn:userTask>\n    <bpmn:endEvent id="end">\n      <bpmn:incoming>SequenceFlow_0apdac1</bpmn:incoming>\n    </bpmn:endEvent>\n    <bpmn:sequenceFlow id="SequenceFlow_0apdac1" sourceRef="userTask" targetRef="end" />\n  </bpmn:process>\n  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="formProcess">\n      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="start">\n        <dc:Bounds x="173" y="102" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_0lj5hpw_di" bpmnElement="SequenceFlow_0lj5hpw">\n        <di:waypoint xsi:type="dc:Point" x="209" y="120" />\n        <di:waypoint xsi:type="dc:Point" x="275" y="120" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="242" y="105" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="UserTask_17ha2pn_di" bpmnElement="userTask">\n        <dc:Bounds x="275" y="80" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="EndEvent_085nv5p_di" bpmnElement="end">\n        <dc:Bounds x="429" y="102" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="447" y="138" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_0apdac1_di" bpmnElement="SequenceFlow_0apdac1">\n        <di:waypoint xsi:type="dc:Point" x="375" y="120" />\n        <di:waypoint xsi:type="dc:Point" x="429" y="120" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="402" y="95" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>',
        'lastModified': 1636152788681,
        'path': '/home/murali/development/javascript/bpmn-engine/test/resources/forms.bpmn',
        'name': 'forms.bpmn'
      },
      {
        'contents': '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.2.2">\n  <bpmn:process id="simpleTaskProcess" isExecutable="true">\n    <bpmn:task id="task" name="Single task" />\n    <bpmn:boundaryEvent id="boundaryEvent" attachedToRef="task">\n      <bpmn:timerEventDefinition>\n        <bpmn:timeDuration xsi:type="bpmn:tFormalExpression">PT0.01S</bpmn:timeDuration>\n      </bpmn:timerEventDefinition>\n    </bpmn:boundaryEvent>\n  </bpmn:process>\n  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="simpleTaskProcess">\n      <bpmndi:BPMNShape id="Task_0gsbfyi_di" bpmnElement="task">\n        <dc:Bounds x="314" y="98" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="BoundaryEvent_1inx7f6_di" bpmnElement="boundaryEvent">\n        <dc:Bounds x="346" y="160" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="319" y="196" width="90" height="20" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>',
        'lastModified': 1636152788685,
        'path': '/home/murali/development/javascript/bpmn-engine/test/resources/simple-task.bpmn',
        'name': 'simple-task.bpmn'
      },
      {
        'contents': '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" id="Signals_0" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="4.1.1">\n  <bpmn:collaboration id="Collaboration_1cap25j">\n    <bpmn:participant id="trader" name="Trader" processRef="tradeProcess" />\n    <bpmn:participant id="priceAdmin" name="Spot Price Admin" processRef="spotPriceProcess" />\n  </bpmn:collaboration>\n  <bpmn:process id="tradeProcess" isExecutable="true">\n    <bpmn:laneSet id="LaneSet_1vkhxd4">\n      <bpmn:lane id="Lane_0qatxdu">\n        <bpmn:flowNodeRef>tradeTask</bpmn:flowNodeRef>\n        <bpmn:flowNodeRef>catchSpotUpdate</bpmn:flowNodeRef>\n        <bpmn:flowNodeRef>startTrade</bpmn:flowNodeRef>\n        <bpmn:flowNodeRef>getSpotPrice</bpmn:flowNodeRef>\n        <bpmn:flowNodeRef>endTrade</bpmn:flowNodeRef>\n      </bpmn:lane>\n    </bpmn:laneSet>\n    <bpmn:userTask id="tradeTask" name="Trade">\n      <bpmn:extensionElements>\n        <camunda:formData>\n          <camunda:formField id="price" label="Price" type="long" defaultValue="${environment.output.spotPrice}" />\n          <camunda:formField id="amount" label="Amount" type="long" />\n        </camunda:formData>\n        <camunda:inputOutput>\n          <camunda:outputParameter name="amount">${content.output.form.amount}</camunda:outputParameter>\n        </camunda:inputOutput>\n      </bpmn:extensionElements>\n      <bpmn:incoming>toTradeTask</bpmn:incoming>\n      <bpmn:outgoing>toEndBuy</bpmn:outgoing>\n    </bpmn:userTask>\n    <bpmn:boundaryEvent id="catchSpotUpdate" name="Spot price changed" attachedToRef="tradeTask">\n      <bpmn:outgoing>backToGetSpotPrice</bpmn:outgoing>\n      <bpmn:signalEventDefinition id="SignalEventDefinition_1nz94rk" signalRef="spotPriceChanged" />\n    </bpmn:boundaryEvent>\n    <bpmn:sequenceFlow id="toGetSpotPrice" sourceRef="startTrade" targetRef="getSpotPrice" />\n    <bpmn:sequenceFlow id="toTradeTask" sourceRef="getSpotPrice" targetRef="tradeTask" />\n    <bpmn:sequenceFlow id="toEndBuy" sourceRef="tradeTask" targetRef="endTrade" />\n    <bpmn:sequenceFlow id="backToGetSpotPrice" sourceRef="catchSpotUpdate" targetRef="getSpotPrice" />\n    <bpmn:startEvent id="startTrade">\n      <bpmn:outgoing>toGetSpotPrice</bpmn:outgoing>\n    </bpmn:startEvent>\n    <bpmn:serviceTask id="getSpotPrice" name="Get spot price" camunda:expression="${environment.services.getSpotPrice}" camunda:resultVariable="spotPrice">\n      <bpmn:incoming>toGetSpotPrice</bpmn:incoming>\n      <bpmn:incoming>backToGetSpotPrice</bpmn:incoming>\n      <bpmn:outgoing>toTradeTask</bpmn:outgoing>\n    </bpmn:serviceTask>\n    <bpmn:endEvent id="endTrade">\n      <bpmn:incoming>toEndBuy</bpmn:incoming>\n    </bpmn:endEvent>\n  </bpmn:process>\n  <bpmn:signal id="spotPriceChanged" name="newSpotPrice" />\n  <bpmn:process id="spotPriceProcess" isExecutable="false">\n    <bpmn:sequenceFlow id="toApprove" sourceRef="startPriceAdmin" targetRef="approveSpotPrice" />\n    <bpmn:sequenceFlow id="toEnd" sourceRef="throwNewSpotPrice" targetRef="endPriceAdmin" />\n    <bpmn:sequenceFlow id="toThrow" sourceRef="approveSpotPrice" targetRef="throwNewSpotPrice" />\n    <bpmn:endEvent id="endPriceAdmin">\n      <bpmn:incoming>toEnd</bpmn:incoming>\n    </bpmn:endEvent>\n    <bpmn:userTask id="approveSpotPrice" name="Approve">\n      <bpmn:extensionElements>\n        <camunda:inputOutput>\n          <camunda:outputParameter name="spotPrice">${content.output.form.newPrice}</camunda:outputParameter>\n        </camunda:inputOutput>\n        <camunda:formData>\n          <camunda:formField id="newPrice" label="Set new spot price" type="long" defaultValue="${environment.variables.message.price}" />\n        </camunda:formData>\n      </bpmn:extensionElements>\n      <bpmn:incoming>toApprove</bpmn:incoming>\n      <bpmn:outgoing>toThrow</bpmn:outgoing>\n    </bpmn:userTask>\n    <bpmn:intermediateThrowEvent id="throwNewSpotPrice" name="Change spot price">\n      <bpmn:extensionElements>\n        <camunda:inputOutput>\n          <camunda:outputParameter name="price">${environment.output.spotPrice}</camunda:outputParameter>\n        </camunda:inputOutput>\n      </bpmn:extensionElements>\n      <bpmn:incoming>toThrow</bpmn:incoming>\n      <bpmn:outgoing>toEnd</bpmn:outgoing>\n      <bpmn:signalEventDefinition signalRef="spotPriceChanged" />\n    </bpmn:intermediateThrowEvent>\n    <bpmn:startEvent id="startPriceAdmin">\n      <bpmn:outgoing>toApprove</bpmn:outgoing>\n      <bpmn:signalEventDefinition signalRef="spotPriceUpdate" />\n    </bpmn:startEvent>\n  </bpmn:process>\n  <bpmn:signal id="spotPriceUpdate" name="newSpotPrice" />\n  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Collaboration_1cap25j">\n      <bpmndi:BPMNShape id="Participant_0ijaois_di" bpmnElement="trader" isHorizontal="true">\n        <dc:Bounds x="156" y="81" width="599" height="223" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="Lane_0qatxdu_di" bpmnElement="Lane_0qatxdu" isHorizontal="true">\n        <dc:Bounds x="186" y="81" width="569" height="223" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_13vmjp7_di" bpmnElement="backToGetSpotPrice">\n        <di:waypoint x="564" y="226" />\n        <di:waypoint x="564" y="246" />\n        <di:waypoint x="391" y="246" />\n        <di:waypoint x="391" y="208" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="SequenceFlow_1p5eppx_di" bpmnElement="toEndBuy">\n        <di:waypoint x="592" y="168" />\n        <di:waypoint x="649" y="168" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="SequenceFlow_0jhted6_di" bpmnElement="toTradeTask">\n        <di:waypoint x="441" y="168" />\n        <di:waypoint x="492" y="168" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="SequenceFlow_1qxrcms_di" bpmnElement="toGetSpotPrice">\n        <di:waypoint x="260" y="168" />\n        <di:waypoint x="341" y="168" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="UserTask_05k81sa_di" bpmnElement="tradeTask">\n        <dc:Bounds x="492" y="128" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="StartEvent_0dl31fx_di" bpmnElement="startTrade">\n        <dc:Bounds x="224" y="150" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="ServiceTask_13834bs_di" bpmnElement="getSpotPrice">\n        <dc:Bounds x="341" y="128" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="EndEvent_1eajl1b_di" bpmnElement="endTrade">\n        <dc:Bounds x="649" y="150" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="BoundaryEvent_12bux0e_di" bpmnElement="catchSpotUpdate">\n        <dc:Bounds x="546" y="190" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="583" y="218" width="50" height="27" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="Participant_1en1l57_di" bpmnElement="priceAdmin" isHorizontal="true">\n        <dc:Bounds x="156" y="330" width="600" height="250" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_0xuufgx_di" bpmnElement="toThrow">\n        <di:waypoint x="437" y="447" />\n        <di:waypoint x="515" y="447" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="SequenceFlow_0yivfto_di" bpmnElement="toEnd">\n        <di:waypoint x="551" y="447" />\n        <di:waypoint x="641" y="447" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNEdge id="SequenceFlow_0aa16x8_di" bpmnElement="toApprove">\n        <di:waypoint x="259" y="447" />\n        <di:waypoint x="337" y="447" />\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="EndEvent_0i1686p_di" bpmnElement="endPriceAdmin">\n        <dc:Bounds x="641" y="429" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="UserTask_12pw7h1_di" bpmnElement="approveSpotPrice">\n        <dc:Bounds x="337" y="407" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="IntermediateThrowEvent_0546il3_di" bpmnElement="throwNewSpotPrice">\n        <dc:Bounds x="515" y="429" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="490" y="472" width="90" height="14" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="StartEvent_15nowqo_di" bpmnElement="startPriceAdmin">\n        <dc:Bounds x="223" y="429" width="36" height="36" />\n      </bpmndi:BPMNShape>\n    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>',
        'lastModified': 1636152788685,
        'path': '/home/murali/development/javascript/bpmn-engine/test/resources/signals.bpmn',
        'name': 'signals.bpmn'
      },
      {
        'contents': '<?xml version="1.0" encoding="UTF-8"?>\n<bpmn:definitions xmlns:bpmn="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:camunda="http://camunda.org/schema/1.0/bpmn" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" id="Definitions_1" targetNamespace="http://bpmn.io/schema/bpmn" exporter="Camunda Modeler" exporterVersion="1.7.2">\n  <bpmn:process id="serviceTaskProcess" isExecutable="true">\n    <bpmn:startEvent id="start">\n      <bpmn:outgoing>flow1</bpmn:outgoing>\n    </bpmn:startEvent>\n    <bpmn:sequenceFlow id="flow1" sourceRef="start" targetRef="serviceTask" />\n    <bpmn:endEvent id="end">\n      <bpmn:incoming>flow2</bpmn:incoming>\n    </bpmn:endEvent>\n    <bpmn:sequenceFlow id="flow2" sourceRef="serviceTask" targetRef="end" />\n    <bpmn:serviceTask id="serviceTask" name="Post message" camunda:expression="${services.postMessage}">\n      <bpmn:incoming>flow1</bpmn:incoming>\n      <bpmn:outgoing>flow2</bpmn:outgoing>\n    </bpmn:serviceTask>\n    <bpmn:boundaryEvent id="errorEvent" attachedToRef="serviceTask">\n      <bpmn:outgoing>flow3</bpmn:outgoing>\n      <bpmn:errorEventDefinition />\n    </bpmn:boundaryEvent>\n    <bpmn:sequenceFlow id="flow3" sourceRef="errorEvent" targetRef="endInVain" />\n    <bpmn:endEvent id="endInVain">\n      <bpmn:incoming>flow3</bpmn:incoming>\n      <bpmn:errorEventDefinition />\n    </bpmn:endEvent>\n    <bpmn:boundaryEvent id="timerEvent" attachedToRef="serviceTask">\n      <bpmn:outgoing>flow4</bpmn:outgoing>\n      <bpmn:timerEventDefinition>\n        <bpmn:timeDuration xsi:type="bpmn:tFormalExpression">PT0.05S</bpmn:timeDuration>\n      </bpmn:timerEventDefinition>\n    </bpmn:boundaryEvent>\n    <bpmn:endEvent id="timeoutEnd">\n      <bpmn:incoming>flow4</bpmn:incoming>\n    </bpmn:endEvent>\n    <bpmn:sequenceFlow id="flow4" sourceRef="timerEvent" targetRef="timeoutEnd" />\n  </bpmn:process>\n  <bpmndi:BPMNDiagram id="BPMNDiagram_1">\n    <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="serviceTaskProcess">\n      <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="start">\n        <dc:Bounds x="173" y="102" width="36" height="36" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_1leakwz_di" bpmnElement="flow1">\n        <di:waypoint xsi:type="dc:Point" x="209" y="120" />\n        <di:waypoint xsi:type="dc:Point" x="271" y="120" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="240" y="105" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="EndEvent_0z6s6tv_di" bpmnElement="end">\n        <dc:Bounds x="433" y="102" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="451" y="138" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_0qci4po_di" bpmnElement="flow2">\n        <di:waypoint xsi:type="dc:Point" x="371" y="120" />\n        <di:waypoint xsi:type="dc:Point" x="433" y="120" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="402" y="105" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="ServiceTask_0wu41vz_di" bpmnElement="serviceTask">\n        <dc:Bounds x="271" y="80" width="100" height="80" />\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="BoundaryEvent_1stbfsc_di" bpmnElement="errorEvent">\n        <dc:Bounds x="280" y="142" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="298" y="178" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_1q9drr5_di" bpmnElement="flow3">\n        <di:waypoint xsi:type="dc:Point" x="298" y="178" />\n        <di:waypoint xsi:type="dc:Point" x="298" y="212" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="313" y="195" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n      <bpmndi:BPMNShape id="EndEvent_18zxth2_di" bpmnElement="endInVain">\n        <dc:Bounds x="280" y="212" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="298" y="248" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="BoundaryEvent_17ohhqn_di" bpmnElement="timerEvent">\n        <dc:Bounds x="326" y="142" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="344" y="178" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNShape id="EndEvent_0bmhnr0_di" bpmnElement="timeoutEnd">\n        <dc:Bounds x="326" y="212" width="36" height="36" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="344" y="248" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNShape>\n      <bpmndi:BPMNEdge id="SequenceFlow_05tti7c_di" bpmnElement="flow4">\n        <di:waypoint xsi:type="dc:Point" x="344" y="178" />\n        <di:waypoint xsi:type="dc:Point" x="344" y="212" />\n        <bpmndi:BPMNLabel>\n          <dc:Bounds x="359" y="185" width="0" height="0" />\n        </bpmndi:BPMNLabel>\n      </bpmndi:BPMNEdge>\n    </bpmndi:BPMNPlane>\n  </bpmndi:BPMNDiagram>\n</bpmn:definitions>',
        'lastModified': 1636152788685,
        'path': '/home/murali/development/javascript/bpmn-engine/test/resources/service-task.bpmn',
        'name': 'service-task.bpmn'
      }
    ],
    'activeFile': 1,
    'layout': {
      'propertiesPanel': {
        'open': false,
        'width': 246
      },
      'minimap': {
        'open': false
      },
      'log': {
        'height': 130,
        'open': false
      }
    },
    'endpoints': []
  },
  'editor.privacyPreferences': {},
  'defaultPath': '/home/murali/development/javascript/bpmn-engine/test/resources',
  'window': {
    'fullScreen': false,
    'maximize': false,
    'bounds': {
      'x': 506,
      'y': 193,
      'width': 1211,
      'height': 807
    }
  },
  'versionInfo': {
    'lastOpenedVersion': '4.11.1'
  }
};

// });

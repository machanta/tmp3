Hi,

The files included in this achive are the following:

RBIFCopy.cbl : Copybook file with record definition for Fixed Width file
RBIVCopy.cbl : Copybook file with record definition for Variable Width file
FujitsuFixedWidthFile.seq : Fixed Width Data file with Fujitsu Data Formats (124 characters in width, no delimiters)
FujitsuVariableWidthFile.seq : Variable Width Data file with Fujitsu File and Data Formats (Record delimiter is Fijitsu format)

Regards

Jean-Francois Gagnon
